package com.rajvadaviya.allpractical;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Practical54Activity extends AppCompatActivity {

    private DoctorDbHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_practical54);
        db = new DoctorDbHelper(this);
        EditText docId = findViewById(R.id.doc_id);
        EditText first = findViewById(R.id.firstname);
        EditText last = findViewById(R.id.lastname);
        EditText mob = findViewById(R.id.mobile);
        EditText addr = findViewById(R.id.address);
        EditText city = findViewById(R.id.city);
        EditText spec = findViewById(R.id.specialization);
        Button save = findViewById(R.id.save);
        EditText searchId = findViewById(R.id.search_id);
        Button search = findViewById(R.id.search);
        TextView result = findViewById(R.id.search_result);
        save.setOnClickListener(v -> {
            long r = db.insertDoctor(
                    docId.getText().toString().trim(),
                    first.getText().toString().trim(),
                    last.getText().toString().trim(),
                    mob.getText().toString().trim(),
                    addr.getText().toString().trim(),
                    city.getText().toString().trim(),
                    spec.getText().toString().trim());
            Toast.makeText(this, "Rows: " + r, Toast.LENGTH_SHORT).show();
        });
        search.setOnClickListener(v -> {
            String id = searchId.getText().toString().trim();
            try (Cursor c = db.findById(id)) {
                if (c != null && c.moveToFirst()) {
                    String line = "ID: " + c.getString(c.getColumnIndexOrThrow(DoctorDbHelper.COL_ID))
                            + "\nName: "
                            + c.getString(c.getColumnIndexOrThrow(DoctorDbHelper.COL_FIRST)) + " "
                            + c.getString(c.getColumnIndexOrThrow(DoctorDbHelper.COL_LAST))
                            + "\nMobile: " + c.getString(c.getColumnIndexOrThrow(DoctorDbHelper.COL_MOB))
                            + "\nAddress: " + c.getString(c.getColumnIndexOrThrow(DoctorDbHelper.COL_ADD))
                            + "\nCity: " + c.getString(c.getColumnIndexOrThrow(DoctorDbHelper.COL_CITY))
                            + "\nSpec: " + c.getString(c.getColumnIndexOrThrow(DoctorDbHelper.COL_SPEC));
                    result.setText(line);
                } else {
                    result.setText("No record for id: " + id);
                }
            }
        });
    }
}

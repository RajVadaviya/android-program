package com.rajvadaviya.allpractical;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Calendar;

public class Practical23Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_practical23);
        TextView label = findViewById(R.id.date_label);
        Button pick = findViewById(R.id.pick_date);
        Calendar cal = Calendar.getInstance();
        pick.setOnClickListener(v -> new DatePickerDialog(this,
                (view, year, month, dayOfMonth) -> label.setText(year + "-" + (month + 1) + "-" + dayOfMonth),
                cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show());
    }
}

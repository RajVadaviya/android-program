package com.rajvadaviya.allpractical;

import android.os.Bundle;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

public class Practical30Activity extends AppCompatActivity {

        @Override
        protected void onCreate(Bundle savedInstanceState) {
                super.onCreate(savedInstanceState);
                setContentView(R.layout.activity_practical30);
                ImageView target = findViewById(R.id.target);
                findViewById(R.id.btn_alpha).setOnClickListener(
                                v -> target.startAnimation(AnimationUtils.loadAnimation(this, R.anim.anim_alpha)));
                findViewById(R.id.btn_scale).setOnClickListener(
                                v -> target.startAnimation(AnimationUtils.loadAnimation(this, R.anim.anim_scale)));
                findViewById(R.id.btn_rotate).setOnClickListener(
                                v -> target.startAnimation(AnimationUtils.loadAnimation(this, R.anim.anim_rotate)));
                findViewById(R.id.btn_translate).setOnClickListener(
                                v -> target.startAnimation(AnimationUtils.loadAnimation(this, R.anim.anim_translate)));
        }
}

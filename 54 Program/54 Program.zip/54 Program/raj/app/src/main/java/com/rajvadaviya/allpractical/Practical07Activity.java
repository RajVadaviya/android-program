package com.rajvadaviya.allpractical;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Practical07Activity extends AppCompatActivity {

    private static final String USER = "admin";
    private static final String PASS = "1234";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_practical07);
        EditText user = findViewById(R.id.username);
        EditText pass = findViewById(R.id.password);
        Button verify = findViewById(R.id.verify);
        verify.setOnClickListener(v -> {
            String u = user.getText().toString();
            String p = pass.getText().toString();
            if (USER.equals(u) && PASS.equals(p)) {
                Intent i = new Intent(this, Practical07ResultActivity.class);
                i.putExtra("u", u);
                i.putExtra("p", p);
                startActivity(i);
            } else {
                Toast.makeText(this, "Verification failed", Toast.LENGTH_SHORT).show();
            }
        });
    }
}

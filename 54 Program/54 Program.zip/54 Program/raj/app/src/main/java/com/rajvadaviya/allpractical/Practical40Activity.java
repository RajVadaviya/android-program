package com.rajvadaviya.allpractical;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class Practical40Activity extends AppCompatActivity {

    private static final int REQ_SMS = 4400;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_practical40);
        EditText dest = findViewById(R.id.dest);
        EditText body = findViewById(R.id.body);
        Button send = findViewById(R.id.send);
        send.setOnClickListener(v -> {
            if (ContextCompat.checkSelfPermission(this,
                    Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[] { Manifest.permission.SEND_SMS }, REQ_SMS);
                return;
            }
            dispatchSms(dest.getText().toString(), body.getText().toString());
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
            @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_SMS && grantResults.length > 0
                && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            EditText dest = findViewById(R.id.dest);
            EditText body = findViewById(R.id.body);
            dispatchSms(dest.getText().toString(), body.getText().toString());
        }
    }

    private void dispatchSms(String dest, String msg) {
        if (dest.trim().isEmpty()) {
            Toast.makeText(this, "Enter destination", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            SmsManager sm = SmsManager.getDefault();
            sm.sendTextMessage(dest, null, msg, null, null);
            Toast.makeText(this, "SMS sent", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }
}

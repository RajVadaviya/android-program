package com.rajvadaviya.allpractical;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Practical10Activity extends AppCompatActivity {

    private EditText numA;
    private EditText numB;
    private TextView result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_practical10);
        numA = findViewById(R.id.num_a);
        numB = findViewById(R.id.num_b);
        result = findViewById(R.id.result);
        findViewById(R.id.btn_clear).setOnClickListener(v -> {
            numA.setText("");
            numB.setText("");
            result.setText("");
        });
        findViewById(R.id.btn_add).setOnClickListener(v -> apply((a, b) -> a + b));
        findViewById(R.id.btn_sub).setOnClickListener(v -> apply((a, b) -> a - b));
        findViewById(R.id.btn_mul).setOnClickListener(v -> apply((a, b) -> a * b));
        findViewById(R.id.btn_div).setOnClickListener(v -> apply((a, b) -> {
            if (b == 0) {
                throw new ArithmeticException("divide");
            }
            return a / b;
        }));
        findViewById(R.id.btn_mod).setOnClickListener(v -> apply((a, b) -> {
            if (b == 0) {
                throw new ArithmeticException("mod");
            }
            return a % b;
        }));
    }

    private void apply(Op op) {
        try {
            double a = Double.parseDouble(numA.getText().toString().trim());
            double b = Double.parseDouble(numB.getText().toString().trim());
            double r = op.apply(a, b);
            result.setText(String.valueOf(r));
        } catch (ArithmeticException e) {
            Toast.makeText(this, "Cannot divide by zero", Toast.LENGTH_SHORT).show();
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Enter valid numbers", Toast.LENGTH_SHORT).show();
        }
    }

    private interface Op {
        double apply(double a, double b);
    }
}

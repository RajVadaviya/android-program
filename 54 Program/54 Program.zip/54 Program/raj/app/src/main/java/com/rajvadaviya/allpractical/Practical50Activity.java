package com.rajvadaviya.allpractical;

import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;
import android.widget.VideoView;

import androidx.appcompat.app.AppCompatActivity;

public class Practical50Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_practical50);
        VideoView video = findViewById(R.id.video);
        Button play = findViewById(R.id.play);
        play.setOnClickListener(v -> {
            Uri u = Uri.parse(
                    "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4");
            video.setVideoURI(u);
            video.setOnPreparedListener(mp -> video.start());
            video.setOnErrorListener((mp, what, extra) -> {
                Toast.makeText(this, "Playback error", Toast.LENGTH_SHORT).show();
                return true;
            });
        });
    }
}
